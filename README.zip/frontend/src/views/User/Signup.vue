<template>
  <div
    class="min-h-screen bg-gray-100 flex flex-col justify-center items-center p-4"
  >
    <div class="max-w-md w-full bg-white rounded-lg shadow-xl overflow-hidden">
      <div class="p-6">
        <svg
          class="mx-auto mb-4 cursor-pointer"
          width="155"
          height="84"
          viewBox="0 0 155 84"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          @click="goToHome"
        >
          <path
            d="M23.5986 18.8899C24.7706 19.002 26.9356 19.5874 28.0763 20.0067C38.9082 23.974 37.6759 39.2239 26.8439 42.0989C34.728 55.8687 43.008 76.6713 60.977 78.9655C66.9868 79.7325 72.8042 77.8756 77.3177 73.8635L78.7134 75.485C70.0711 85.3099 55.9401 86.3056 44.8062 80.1519C34.5066 74.4578 28.5124 63.5093 23.1445 53.4309C21.8093 50.9237 20.2012 46.5483 18.6624 44.4694C17.4456 42.8255 16.1059 43.4176 14.3166 43.3324V58.0216C14.3166 58.1539 14.9585 59.4838 15.1128 59.6901C16.0545 60.9594 18.0137 61.0783 19.4631 61.0469L19.5973 62.8275L19.3535 63.2828L0.00223662 63.294V61.0491C3.75305 61.3564 4.91833 59.4546 5.15765 56.0144C5.86218 45.862 4.6298 34.8731 5.12186 24.6333C4.75058 21.5631 2.68618 21.1662 0.0268394 20.8836L0 18.8899H23.5986ZM15.3768 21.8592C15.0502 21.9197 14.4597 22.0475 14.3457 22.3951V40.0514C14.5313 40.6188 16.3452 40.4483 16.8977 40.4281C24.983 40.1344 27.8392 34.4224 25.6585 26.9163C24.3053 22.2561 19.8321 21.0496 15.3768 21.8614V21.8592Z"
            fill="#000000"
          />
          <path
            d="M115.188 35.7097L116.302 34.2475C120.726 29.0176 130.241 29.067 132.412 36.3824C133.94 34.6063 135.273 32.7359 137.469 31.7021C142.305 29.4213 149.927 30.823 150.73 36.9633C151.567 43.3503 149.784 51.9037 150.849 58.1494C151.276 60.6522 152.745 60.8518 154.987 61.0648L154.998 63.072H139.677C139.214 62.8051 139.209 61.3541 139.438 61.0379C139.625 60.7755 140.437 60.8271 140.847 60.6567C142.092 60.1341 142.493 59.3021 142.672 58.0014C142.372 52.184 143.155 45.8306 142.705 40.0761C142.211 33.7496 135.553 34.3865 132.862 38.7439C133.296 44.7542 132.249 51.6435 132.884 57.5484C133.101 59.5645 133.98 61.0559 136.201 61.0626L136.21 63.072H121.448L121.471 61.0761C123.432 60.955 124.423 59.9009 124.783 58.0081C124.448 52.2984 125.302 45.9473 124.799 40.3138C124.508 37.0597 122.949 35.1557 119.534 35.4764C118.264 35.5953 115.349 37.1696 115.173 38.504L115.204 58.2324C115.512 59.9166 116.481 61.2129 118.315 61.0581C117.745 61.7802 118.543 62.6078 117.979 63.0742H103.777L103.799 61.0783C106.295 60.8339 106.884 59.6542 107.103 57.3264C107.559 52.4778 107.505 43.6351 107.141 38.7327C106.969 36.4116 106.318 35.1064 103.786 35.0346L103.609 33.1261C103.705 32.5767 105.383 32.8548 105.897 32.7965C108.973 32.4489 111.927 31.5339 114.924 31.036C114.947 31.2064 115.181 31.4845 115.181 31.5653V35.7141L115.188 35.7097Z"
            fill="#000000"
          />
          <path
            d="M53.8533 30.6122C71.9901 30.204 75.6 60.2889 56.4031 63.6708C34.7414 67.4877 32.129 31.101 53.8533 30.6122ZM52.9497 33.5208C50.7959 33.8864 49.2996 36.4565 48.5883 38.3403C46.6537 43.4714 45.7747 59.8157 53.1734 60.9953C60.7623 62.2041 60.93 49.1654 60.6102 44.346C60.3328 40.1702 58.6151 32.561 52.9497 33.5208Z"
            fill="#000000"
          />
          <path
            d="M86.9307 30.6346C107.076 30.5 107.579 63.2245 87.5749 63.9735C67.1948 64.736 66.9018 30.7669 86.9307 30.6346ZM83.7301 59.6251C85.5731 61.3833 88.4986 61.612 90.4668 59.9233C95.0228 56.0144 94.6806 41.1458 91.6634 36.3084C89.6527 33.0835 85.8482 32.3569 83.3141 35.4809C79.7131 39.9191 79.4313 55.5211 83.7323 59.6251H83.7301Z"
            fill="#000000"
          />
          <path
            d="M33.3279 0.500339L38.3625 11.4915L43.5045 0.500339H48.5369V1.39291C47.8167 1.35478 47.1368 1.34357 46.978 2.18904L47.1882 13.1802C47.309 14.6042 47.5483 15.5708 49.1967 15.5417L49.2101 16.4253H42.0529L42.082 15.5551C42.5114 15.4721 42.9565 15.4116 43.2943 15.0909C44.4908 13.9539 43.5649 7.28654 43.6163 5.43637L37.9174 16.6675L37.1547 16.2885L31.5386 5.43637V14.7433C31.5386 15.2456 33.4017 15.2838 33.3212 16.3154C32.979 16.8671 32.8515 16.4253 32.7687 16.4253H27.289V15.5327C28.0562 15.5798 28.8792 15.4609 29.2595 14.6984L29.5211 2.4133C29.3668 1.59699 28.4498 1.37945 27.7497 1.38618L27.7363 0.502582H33.3279V0.500339Z"
            fill="#000000"
          />
          <path
            d="M113.734 0.500339C113.824 0.500339 114.014 0.0966656 114.287 0.619199L114.296 1.39739C113.822 1.14397 112.504 1.80107 112.504 2.18231V7.4525H119.438V2.18231C119.438 1.56783 118.431 1.22919 117.872 1.39515V0.500339H124.582V1.39291C123.412 1.3346 123.115 1.4557 123.003 2.61738C122.636 6.43434 123.296 10.8501 123.023 14.7343C123.182 15.5775 123.862 15.5708 124.582 15.526V16.6473C123.73 16.2503 123.074 16.6652 122.229 16.6675C120.784 16.6697 119.268 16.1584 117.872 16.6473L117.879 15.5349C118.393 15.5775 119.436 15.3623 119.436 14.741V9.47086H112.502V14.741C112.502 15.3623 113.544 15.5775 114.059 15.5349L114.068 16.6473L107.816 16.5531L107.376 16.2952L107.36 15.526L108.651 15.2479C108.901 14.898 108.901 14.4854 108.935 14.0772C109.254 10.2805 108.684 6.03515 108.919 2.18904C108.675 0.910741 107.201 2.00066 107.584 0.500339C109.63 0.486883 111.686 0.51828 113.734 0.500339Z"
            fill="#000000"
          />
          <path
            d="M52.3391 16.423L52.3526 15.5394C53.2226 15.5641 53.907 15.2389 54.2537 14.4159L59.8296 0.720117L62.6544 0.632654L67.9127 14.3777C68.2773 15.3309 69.0556 15.5192 69.9995 15.5372L70.0084 16.6473C69.7669 16.7325 69.5186 16.423 69.4515 16.423H62.4062L62.433 15.5506C64.938 15.4094 63.7795 13.6713 63.3277 12.0701L57.5169 11.9669C56.9846 13.5592 55.6963 15.4609 58.3691 15.5394L58.3825 16.423H52.3391ZM62.4039 10.1437C62.0036 8.62539 61.4892 6.72364 60.8495 5.31078C60.7488 5.08876 60.6996 4.78601 60.3932 4.76134L58.378 10.1437H62.4039Z"
            fill="#000000"
          />
          <path
            d="M102.475 4.71873C102.375 4.66042 101.661 3.30363 101.102 2.85062C98.541 0.771698 94.9423 2.16213 93.399 4.77928C90.0799 10.4173 94.9087 17.9435 100.941 14.3598C102.008 13.7251 102.247 12.9626 103.22 12.3885C104.781 14.5437 101.648 16.5082 99.8159 16.82C95.4142 17.5645 89.9949 16.0261 88.682 11.2717C86.792 4.42046 92.8443 -0.677042 99.3976 0.0787246C100.74 0.233466 101.648 1.09912 102.992 0.280561C103.661 0.453244 103.115 3.63778 103.542 4.40252C103.435 4.78376 102.77 4.8959 102.477 4.72546L102.475 4.71873Z"
            fill="#000000"
          />
          <path
            d="M85.6648 0.500339L85.8884 4.53708L84.8059 4.49895C84.3519 2.31239 81.8849 1.48037 80.0732 2.40433V14.5145C80.0732 15.582 82.0169 15.147 81.99 16.1853C81.9676 17.0353 80.7912 16.4253 80.194 16.4118C78.4226 16.3737 76.4052 16.284 74.7076 16.645V15.5237C75.3853 15.5641 76.0294 15.5035 76.4946 14.9631V2.07018C75.1683 2.02533 73.6251 1.95581 72.6901 3.07712C71.9923 3.91587 72.3793 4.86674 70.9031 4.53708L71.1268 0.500339H85.6648Z"
            fill="#000000"
          />
        </svg>
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-8">
          Créer un compte {{ isHotelier ? "Hôtelier" : "Voyageur" }}
        </h2>
        <form @submit.prevent="handleRegister" class="space-y-6">
          <div class="relative mt-4">
            <svg
              class="absolute left-3 top-1/2 transform -translate-y-1/2 pointer-events-none"
              width="15"
              height="15"
              viewBox="0 0 15 15"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M7.5 6.25C8.88071 6.25 10 5.13071 10 3.75C10 2.36929 8.88071 1.25 7.5 1.25C6.11929 1.25 5 2.36929 5 3.75C5 5.13071 6.11929 6.25 7.5 6.25Z"
                fill="#CACACA"
              />
              <path
                d="M12.5 10.9375C12.5 12.4906 12.5 13.75 7.5 13.75C2.5 13.75 2.5 12.4906 2.5 10.9375C2.5 9.38438 4.73875 8.125 7.5 8.125C10.2613 8.125 12.5 9.38438 12.5 10.9375Z"
                fill="#CACACA"
              />
            </svg>

						<input
							type="text"
							id="name"
							v-model="form.name"
							:placeholder="isHotelier ? 'Entrer le nom de votre hotel' : 'Entrer votre email'"
							class="w-full px-8 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-yellow-500"
							required
						/>
					</div>
					<div class="relative mt-4">
						<svg
							class="absolute left-3 top-1/2 transform -translate-y-1/2 pointer-events-none"
							width="15"
							height="15"
							viewBox="0 0 15 15"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								d="M12.5 2.5H2.5C1.8125 2.5 1.25625 3.0625 1.25625 3.75L1.25 11.25C1.25 11.9375 1.8125 12.5 2.5 12.5H12.5C13.1875 12.5 13.75 11.9375 13.75 11.25V3.75C13.75 3.0625 13.1875 2.5 12.5 2.5ZM12.25 5.15625L7.83125 7.91875C7.63125 8.04375 7.36875 8.04375 7.16875 7.91875L2.75 5.15625C2.68733 5.12107 2.63245 5.07354 2.58868 5.01653C2.54491 4.95953 2.51316 4.89424 2.49536 4.82461C2.47756 4.75498 2.47406 4.68246 2.4851 4.61144C2.49613 4.54042 2.52146 4.47238 2.55955 4.41144C2.59764 4.35049 2.6477 4.29791 2.7067 4.25687C2.7657 4.21583 2.83242 4.18719 2.90281 4.17269C2.9732 4.15818 3.0458 4.1581 3.11622 4.17247C3.18664 4.18683 3.25341 4.21533 3.3125 4.25625L7.5 6.875L11.6875 4.25625C11.7466 4.21533 11.8134 4.18683 11.8838 4.17247C11.9542 4.1581 12.0268 4.15818 12.0972 4.17269C12.1676 4.18719 12.2343 4.21583 12.2933 4.25687C12.3523 4.29791 12.4024 4.35049 12.4404 4.41144C12.4785 4.47238 12.5039 4.54042 12.5149 4.61144C12.5259 4.68246 12.5224 4.75498 12.5046 4.82461C12.4868 4.89424 12.4551 4.95953 12.4113 5.01653C12.3676 5.07354 12.3127 5.12107 12.25 5.15625Z"
								fill="#CBCBCB"
							/>
						</svg>

            <input
              type="email"
              id="email"
              v-model="form.email"
              placeholder="Entrer votre email"
              class="w-full px-8 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-yellow-500"
              required
            />
          </div>
          <div class="relative mt-4">
            <svg
              class="absolute left-3 top-1/2 transform -translate-y-1/2 pointer-events-none"
              width="15"
              height="15"
              viewBox="0 0 15 15"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M7.5 10.625C7.83152 10.625 8.14946 10.4933 8.38388 10.2589C8.6183 10.0245 8.75 9.70652 8.75 9.375C8.75 9.04348 8.6183 8.72554 8.38388 8.49112C8.14946 8.2567 7.83152 8.125 7.5 8.125C7.16848 8.125 6.85054 8.2567 6.61612 8.49112C6.3817 8.72554 6.25 9.04348 6.25 9.375C6.25 9.70652 6.3817 10.0245 6.61612 10.2589C6.85054 10.4933 7.16848 10.625 7.5 10.625ZM11.25 5C11.5815 5 11.8995 5.1317 12.1339 5.36612C12.3683 5.60054 12.5 5.91848 12.5 6.25V12.5C12.5 12.8315 12.3683 13.1495 12.1339 13.3839C11.8995 13.6183 11.5815 13.75 11.25 13.75H3.75C3.41848 13.75 3.10054 13.6183 2.86612 13.3839C2.6317 13.1495 2.5 12.8315 2.5 12.5V6.25C2.5 5.91848 2.6317 5.60054 2.86612 5.36612C3.10054 5.1317 3.41848 5 3.75 5H4.375V3.75C4.375 2.9212 4.70424 2.12634 5.29029 1.54029C5.87634 0.95424 6.6712 0.625 7.5 0.625C7.91038 0.625 8.31674 0.705831 8.69589 0.862876C9.07503 1.01992 9.41953 1.25011 9.70971 1.54029C9.99989 1.83047 10.2301 2.17497 10.3871 2.55411C10.5442 2.93326 10.625 3.33962 10.625 3.75V5H11.25ZM7.5 1.875C7.00272 1.875 6.52581 2.07254 6.17417 2.42417C5.82254 2.77581 5.625 3.25272 5.625 3.75V5H9.375V3.75C9.375 3.25272 9.17746 2.77581 8.82583 2.42417C8.47419 2.07254 7.99728 1.875 7.5 1.875Z"
                fill="#CACACA"
              />
            </svg>

						<input
							type="password"
							id="password"
							v-model="form.password"
							placeholder="Entrer votre mot de passe"
							class="w-full px-8 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-yellow-500"
							required
							minlength="8"
						/>
					</div>
					<div class="relative mt-4">
						<svg
							class="absolute left-3 top-1/2 transform -translate-y-1/2 pointer-events-none"
							width="15"
							height="15"
							viewBox="0 0 15 15"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								d="M7.5 10.625C7.83152 10.625 8.14946 10.4933 8.38388 10.2589C8.6183 10.0245 8.75 9.70652 8.75 9.375C8.75 9.04348 8.6183 8.72554 8.38388 8.49112C8.14946 8.2567 7.83152 8.125 7.5 8.125C7.16848 8.125 6.85054 8.2567 6.61612 8.49112C6.3817 8.72554 6.25 9.04348 6.25 9.375C6.25 9.70652 6.3817 10.0245 6.61612 10.2589C6.85054 10.4933 7.16848 10.625 7.5 10.625ZM11.25 5C11.5815 5 11.8995 5.1317 12.1339 5.36612C12.3683 5.60054 12.5 5.91848 12.5 6.25V12.5C12.5 12.8315 12.3683 13.1495 12.1339 13.3839C11.8995 13.6183 11.5815 13.75 11.25 13.75H3.75C3.41848 13.75 3.10054 13.6183 2.86612 13.3839C2.6317 13.1495 2.5 12.8315 2.5 12.5V6.25C2.5 5.91848 2.6317 5.60054 2.86612 5.36612C3.10054 5.1317 3.41848 5 3.75 5H4.375V3.75C4.375 2.9212 4.70424 2.12634 5.29029 1.54029C5.87634 0.95424 6.6712 0.625 7.5 0.625C7.91038 0.625 8.31674 0.705831 8.69589 0.862876C9.07503 1.01992 9.41953 1.25011 9.70971 1.54029C9.99989 1.83047 10.2301 2.17497 10.3871 2.55411C10.5442 2.93326 10.625 3.33962 10.625 3.75V5H11.25ZM7.5 1.875C7.00272 1.875 6.52581 2.07254 6.17417 2.42417C5.82254 2.77581 5.625 3.25272 5.625 3.75V5H9.375V3.75C9.375 3.25272 9.17746 2.77581 8.82583 2.42417C8.47419 2.07254 7.99728 1.875 7.5 1.875Z"
								fill="#CACACA"
							/>
						</svg>
						<input
							type="password"
							id="confirmPassword"
							v-model="form.confirmPassword"
							placeholder="Confirmer votre mot de passe"
							class="w-full px-8 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-yellow-500"
							required
						/>
					</div>
					<!-- Champs spécifiques hôtelier -->
					<div v-if="isHotelier">
						<label
							for="description"
							class="text-sm font-medium text-gray-700 block mb-2"
							>Description de l'hôtel</label
						>
						<textarea
							id="description"
							v-model="form.description"
							placeholder="Décrivez votre établissement"
							class="w-full px-8 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
						></textarea>
					</div>
					<div v-if="isHotelier">
						<label
							for="siret"
							class="text-sm font-medium text-gray-700 block mb-2"
							>SIRET</label
						>
						<input
							type="text"
							id="siret"
							v-model="form.siret"
							:maxlength="14"
							:pattern="isHotelier ? '^[0-9]{14}$' : ''"
							placeholder="Numéro SIRET"
							class="w-full px-8 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-yellow-500"
						/>
					</div>
					<div v-if="isHotelier">
						<label
							for="tags"
							class="text-sm font-medium text-gray-700 block mb-2"
							>Tags (séparés par des virgules)</label
						>
						<input
							type="text"
							id="tags"
							v-model="form.tags"
							placeholder="ex: piscine, wifi, parking"
							class="w-full px-8 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-yellow-500"
						/>
					</div>
					<div v-if="isHotelier">
						<label
							for="rate"
							class="text-sm font-medium text-gray-700 block mb-2"
							>Taux</label
						>
						<input
							type="number"
							id="rate"
							v-model="form.rate"
							min="0"
							max="100"
							step="1"
							placeholder="Taux %"
							class="w-full px-8 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-yellow-500"
						/>
					</div>
					<div class="flex items-center">
						<input
							type="checkbox"
							id="terms"
							v-model="acceptTerms"
							class="h-4 w-4 text-yellow-600 border-gray-300 rounded focus:ring-yellow-500"
							required
						/>
						<label for="terms" class="ml-2 text-sm text-gray-700">
							J'accepte les
							<a href="#" class="text-yellow-600 hover:underline"
								>conditions d'utilisation</a
							>
						</label>
					</div>
					<div>
						<button
							type="submit"
							class="w-full bg-black text-white py-2 px-8 rounded-full hover:bg-yellow-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500"
						>
							{{ isLoading ? "Inscription en cours..." : "S'inscrire" }}
						</button>
					</div>
				</form>
				<div
					v-if="successMessage"
					class="mt-4 p-3 bg-green-100 text-green-700 rounded-lg"
				>
					{{ successMessage }}
				</div>
				<div
					v-if="errorMessage"
					class="mt-4 p-3 bg-red-100 text-red-700 rounded-lg"
				>
					{{ errorMessage }}
				</div>
			</div>
			<div class="py-4 px-6 border-gray-100 flex justify-center">
				<p class="text-sm text-gray-600">
					Déjà un compte?
					<router-link to="/signin" class="text-yellow-600 hover:underline"
						>Se connecter</router-link
					>
				</p>
			</div>
			<p class="text-center text-gray-500 text-sm px-6 py-4">
				En vous inscrivant, vous consentez à la politique de confidentialité et
				aux conditions générales d'utilisation..
			</p>
		</div>
	</div>
</template>

<script>
import axios from "axios";

export default {
  name: "SignUp",
  data() {
    return {
      form: {
        name: "",
        email: "",
        password: "",
        confirmPassword: "",
        // device: "",
        // adress: "",
        // compAdress: "",
        // postCode: "",
        // city: "",
        // profilePic: "",
        // Hotelier only
        // description: "",
        // siret: "",
        // tags: "",
        // rate: "",
      },
      acceptTerms: false,
      isLoading: false,
      errorMessage: "",
      successMessage: "",
    };
  },
  computed: {
    isHotelier() {
      return this.$route.query.type === "hotelier";
    },
    role() {
      return this.isHotelier ? "hotelier" : "voyageur";
    },
  },
  methods: {
    validateForm() {
      if (this.form.name.trim() === "") {
        this.errorMessage = "Le nom est obligatoire";
        return false;
      }
      if (this.form.email.trim() === "") {
        this.errorMessage = "L'email est obligatoire";
        return false;
      }
      if (!/^\S+@\S+\.\S+$/.test(this.form.email)) {
        this.errorMessage = "Veuillez entrer une adresse email valide";
        return false;
      }
      if (this.form.password.length < 8) {
        this.errorMessage =
          "Le mot de passe doit contenir au moins 8 caractères";
        return false;
      }
      if (this.form.password !== this.form.confirmPassword) {
        this.errorMessage = "Les mots de passe ne correspondent pas";
        return false;
      }

				if (!this.acceptTerms) {
					this.errorMessage =
						"Vous devez accepter les conditions d'utilisation";
					return false;
				}
				if (this.isHotelier) {
					if (!this.form.siret.trim()) {
						this.errorMessage =
							"Le numéro SIRET est obligatoire pour les hôteliers";
						return false;
					}
					if (!this.form.description.trim()) {
						this.errorMessage = "La description de l'hôtel est obligatoire";
						return false;
					}
				}
				return true;
			},
			async handleRegister() {
				this.errorMessage = "";
				if (!this.validateForm()) {
					return;
				}
				try {
					this.isLoading = true;
					const payload = {
						...this.form,
						role: this.role,
						status: "active",
						tags:
							this.isHotelier && this.form.tags
								? this.form.tags.split(",").map((t) => t.trim())
								: undefined,
					};
					// Nettoyer les champs inutiles pour voyageur
					if (!this.isHotelier) {
						delete payload.description;
						delete payload.siret;
						delete payload.tags;
						delete payload.rate;
					}
					// Nettoyer confirmPassword
					delete payload.confirmPassword;

        await axios.post(
          // `http://localhost:3001/auth/register`,
          `${window.config.BACKEND_URL}/auth/register`,
          payload
        );

        this.successMessage =
          "Inscription réussie ! Vous pouvez maintenant vous connecter.";
        setTimeout(() => {
          this.$router.push("/signin");
        }, 2000);
      } catch (error) {
        if (error.response) {
          const status = error.response.status;
          if (status === 409) {
            this.errorMessage = "Cette adresse email est déjà utilisée";
          } else if (status === 400) {
            this.errorMessage =
              error.response.data.message ||
              "Les données fournies sont incorrectes";
          } else if (status === 500) {
            this.errorMessage = "Erreur serveur. Veuillez réessayer plus tard";
          } else {
            this.errorMessage =
              error.response.data.message || "Erreur lors de l'inscription";
          }
        } else if (error.request) {
          this.errorMessage =
            "Impossible de joindre le serveur. Vérifiez votre connexion internet";
        } else {
          this.errorMessage = "Erreur lors de l'envoi de la demande";
        }
        console.error("Erreur d'inscription:", error);
      } finally {
        this.isLoading = false;
      }
    },
    goToHome() {
      this.$router.push("/");
    },
  },
};
</script>
